Ultrasonic Sensor HC-SR04 by jeremy2nis on Thingiverse: https://www.thingiverse.com/thing:1377355

Summary:
Ultrasonic Sensor HC-SR04 for Arduino